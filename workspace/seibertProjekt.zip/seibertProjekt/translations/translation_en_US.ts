<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hallo hier kannst du dich über Treffer informieren</source>
            <comment>Text</comment>
            <translation type="obsolete">Hallo hier kannst du dich über Treffer informieren</translation>
        </message>
        <message>
            <source>hier kannst du dich über Treffer informieren</source>
            <comment>Text</comment>
            <translation type="obsolete">hier kannst du dich über Treffer informieren</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (1)</name>
        <message>
            <source>Hallo, wähle aus worüber du dich informieren möchtest.</source>
            <comment>Text</comment>
            <translation type="obsolete">Hallo, wähle aus worüber du dich informieren möchtest.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (2)</name>
        <message>
            <source>Das Bafög ist eine tolle Sache</source>
            <comment>Text</comment>
            <translation type="obsolete">Das Bafög ist eine tolle Sache</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (3)</name>
        <message>
            <source>Beim Bafögamt kannst du dich informieren</source>
            <comment>Text</comment>
            <translation type="obsolete">Beim Bafögamt kannst du dich informieren</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Begrüßung</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hallo, wähle aus worüber du dich informieren möchtest.</source>
            <comment>Text</comment>
            <translation type="unfinished">Hallo, wähle aus worüber du dich informieren möchtest.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/MeinText</name>
        <message>
            <source>hier kannst du dich über Treffer informieren</source>
            <comment>Text</comment>
            <translation type="obsolete">hier kannst du dich über Treffer informieren</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Treffer</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>hier kannst du dich über Treffer informieren</source>
            <comment>Text</comment>
            <translation type="unfinished">hier kannst du dich über Treffer informieren</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/bAllgemein</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Das Bafög ist eine tolle Sache</source>
            <comment>Text</comment>
            <translation type="unfinished">Das Bafög ist eine tolle Sache</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/bAnsprechpartner</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Beim Bafögamt kannst du dich informieren</source>
            <comment>Text</comment>
            <translation type="unfinished">Beim Bafögamt kannst du dich informieren</translation>
        </message>
    </context>
</TS>

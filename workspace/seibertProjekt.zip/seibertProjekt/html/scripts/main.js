
// タッチイベントによるハンドラ
$(function() {
  $('#fast_button').on({
      'touchstart': function () {
          $.raiseALMemoryEvent("SBR/Test/Tablet/FastTouch", 1);
      },
  });
});

// HTML onClickeによるハンドラ
function slowRep(){
  $.raiseALMemoryEvent("SBR/Test/Tablet/SlowTouch", 1);
}

function bafoegallgemein(){
  $.raiseALMemoryEvent("SBR/Test/Tablet/bafoegallgemein", 1);
}

function bafoegansprechpartner(){
  $.raiseALMemoryEvent("SBR/Test/Tablet/bafoegansprechpartner", 1);
}

function text1OnClick(){
  $.raiseALMemoryEvent("SBR/Test/Tablet/TextEvent", "Hallo");
}

function text2OnClick(){
  $.raiseALMemoryEvent("SBR/Test/Tablet/TextEvent", "Hallo Text2");
}

function textOnClick(meinText){
  console.log("Text: " + meinText);
  $.raiseALMemoryEvent("SBR/Test/Tablet/TextEvent", meinText);
}

var element = document.getElementById("ain");
element.addEventListener('click', textOnClick('Dies ist jetzt A I N'), false);


